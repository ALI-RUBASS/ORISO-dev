/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: userservice
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Sequence structure for `sequence_admin_agency`
--

DROP SEQUENCE IF EXISTS `sequence_admin_agency`;
CREATE SEQUENCE `sequence_admin_agency` start with 0 minvalue 0 maxvalue 9223372036854775806 increment by 1 cache 100 nocycle ENGINE=InnoDB;
DO SETVAL(`sequence_admin_agency`, 100000, 0);

--
-- Sequence structure for `sequence_chat`
--

DROP SEQUENCE IF EXISTS `sequence_chat`;
CREATE SEQUENCE `sequence_chat` start with 0 minvalue 0 maxvalue 9223372036854775806 increment by 1 cache 100 nocycle ENGINE=InnoDB;
DO SETVAL(`sequence_chat`, 300, 0);

--
-- Sequence structure for `sequence_chat_agency`
--

DROP SEQUENCE IF EXISTS `sequence_chat_agency`;
CREATE SEQUENCE `sequence_chat_agency` start with 0 minvalue 0 maxvalue 9223372036854775806 increment by 1 cache 100 nocycle ENGINE=InnoDB;
DO SETVAL(`sequence_chat_agency`, 200, 0);

--
-- Sequence structure for `sequence_consultant_agency`
--

DROP SEQUENCE IF EXISTS `sequence_consultant_agency`;
CREATE SEQUENCE `sequence_consultant_agency` start with 0 minvalue 0 maxvalue 9223372036854775806 increment by 1 cache 100 nocycle ENGINE=InnoDB;
DO SETVAL(`sequence_consultant_agency`, 100400, 0);

--
-- Sequence structure for `sequence_consultant_mobile_token`
--

DROP SEQUENCE IF EXISTS `sequence_consultant_mobile_token`;
CREATE SEQUENCE `sequence_consultant_mobile_token` start with 0 minvalue 0 maxvalue 9223372036854775806 increment by 1 cache 100 nocycle ENGINE=InnoDB;
DO SETVAL(`sequence_consultant_mobile_token`, 0, 0);

--
-- Sequence structure for `sequence_session`
--

DROP SEQUENCE IF EXISTS `sequence_session`;
CREATE SEQUENCE `sequence_session` start with 0 minvalue 0 maxvalue 9223372036854775806 increment by 1 cache 100 nocycle ENGINE=InnoDB;
DO SETVAL(`sequence_session`, 101900, 0);

--
-- Sequence structure for `sequence_session_data`
--

DROP SEQUENCE IF EXISTS `sequence_session_data`;
CREATE SEQUENCE `sequence_session_data` start with 0 minvalue 0 maxvalue 9223372036854775806 increment by 1 cache 100 nocycle ENGINE=InnoDB;
DO SETVAL(`sequence_session_data`, 100, 0);

--
-- Sequence structure for `sequence_session_topic`
--

DROP SEQUENCE IF EXISTS `sequence_session_topic`;
CREATE SEQUENCE `sequence_session_topic` start with 0 minvalue 0 maxvalue 9223372036854775806 increment by 1 cache 10 nocycle ENGINE=InnoDB;
DO SETVAL(`sequence_session_topic`, 100000, 0);

--
-- Sequence structure for `sequence_user_agency`
--

DROP SEQUENCE IF EXISTS `sequence_user_agency`;
CREATE SEQUENCE `sequence_user_agency` start with 0 minvalue 0 maxvalue 9223372036854775806 increment by 1 cache 100 nocycle ENGINE=InnoDB;
DO SETVAL(`sequence_user_agency`, 100, 0);

--
-- Sequence structure for `sequence_user_chat`
--

DROP SEQUENCE IF EXISTS `sequence_user_chat`;
CREATE SEQUENCE `sequence_user_chat` start with 0 minvalue 0 maxvalue 9223372036854775806 increment by 1 cache 10 nocycle ENGINE=InnoDB;
DO SETVAL(`sequence_user_chat`, 0, 0);

--
-- Sequence structure for `sequence_user_mobile_token`
--

DROP SEQUENCE IF EXISTS `sequence_user_mobile_token`;
CREATE SEQUENCE `sequence_user_mobile_token` start with 0 minvalue 0 maxvalue 9223372036854775806 increment by 1 cache 100 nocycle ENGINE=InnoDB;
DO SETVAL(`sequence_user_mobile_token`, 0, 0);

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOG`
--

LOCK TABLES `DATABASECHANGELOG` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOG` DISABLE KEYS */;
INSERT INTO `DATABASECHANGELOG` VALUES
('initSql-tables','initialSetup','db/changelog/changeset/0001_initsql/initSql.xml','2025-09-06 15:03:28',1,'EXECUTED','8:31cd34a0d7a21ad623a6157784a3183a','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('initSql-trigger','initialSetup','db/changelog/changeset/0001_initsql/initSql.xml','2025-09-06 15:03:28',2,'EXECUTED','8:bde546e00bcb5de62e5a1253ea884558','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-1323-monitoringKeys','COBH-1323','db/changelog/changeset/0002_monitoringKeys_feedbackChatClumn/0002_changeSet.xml','2025-09-06 15:03:28',3,'EXECUTED','8:858f9493e5916c5a4526b740ea9a228f','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-1323-feedbackChatColumn','COBH-1323','db/changelog/changeset/0002_monitoringKeys_feedbackChatClumn/0002_changeSet.xml','2025-09-06 15:03:28',4,'EXECUTED','8:c92036b3cd9574432ba0dd564d7235d0','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-1619-user_attribute_languageFormal','COBH-1619','db/changelog/changeset/0003_user_attribute_languageFormal/0003_changeSet.xml','2025-09-06 15:03:29',5,'EXECUTED','8:3afe67e527dd73e46905dba35e5b8c63','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-1619-consultant_attribute_languageFormal','COBH-1619','db/changelog/changeset/0004_consultant_attribute_languageFormal/0004_changeSet.xml','2025-09-06 15:03:29',6,'EXECUTED','8:17b207009da55a0872ef47ba4ba18e5e','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-1859-session_attribute_isMonitoring','COBH-1859','db/changelog/changeset/0005_session_attribute_isMonitoring/0005_changeSet.xml','2025-09-06 15:03:29',7,'EXECUTED','8:f3a2d83474bf3be322257a88f6b20605','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-2046_database_extension_for_chat','COBH-2046','db/changelog/changeset/0006_chat/0006_changeSet.xml','2025-09-06 15:03:29',8,'EXECUTED','8:63d1ba4a519c96c88b9f32889c89a30d','sqlFile; sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-2046_user_agency_relation','COBH-2046','db/changelog/changeset/0007_user_agency_relation/0007_changeSet.xml','2025-09-06 15:03:29',9,'EXECUTED','8:31d8adf566a9752541491bae3ae02b34','sqlFile; sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-2046_chat_extension','COBH-2046','db/changelog/changeset/0008_chat_extension/0008_changeSet.xml','2025-09-06 15:03:29',10,'EXECUTED','8:3562956a36f6f6d6d42cf59a388fba86','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-2345_consultant_user_extension','COBH-2345','db/changelog/changeset/0009_delete_timestamp_for_user_consultant/0009_changeSet.xml','2025-09-06 15:03:29',11,'EXECUTED','8:1c1dcbfbd6b49c858ddda0320ed552a3','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-2345_consultant_user_extension','COBH-2345','db/changelog/changeset/0010_delete_timestamp_for_consultant_agency/0010_changeSet.xml','2025-09-06 15:03:29',12,'EXECUTED','8:7669cc761ac17d80ad7fc7aa84da70c6','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-3498_user_mobile_token','COBH-3498','db/changelog/changeset/0011_add_mobile_token_for_user/0011_changeSet.xml','2025-09-06 15:03:29',13,'EXECUTED','8:28d510e722c6db790e8e1c66c1214868','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-3674_add_type_to_session','COBH-3674','db/changelog/changeset/0012_add_type_to_session/0012_changeSet.xml','2025-09-06 15:03:29',14,'EXECUTED','8:e2bd66b116f2b5fe8b598ff0387c1723','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-3932_assign_date','COBH-3932','db/changelog/changeset/0013_add_assign_date_to_session/0013_changeSet.xml','2025-09-06 15:03:29',15,'EXECUTED','8:75e1921948515d1fd530fbb8bdabee8d','sqlFile; sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-3885','COBH-3885','db/changelog/changeset/0014_add_is_peer_chat_to_session/0014_changeSet.xml','2025-09-06 15:03:29',16,'EXECUTED','8:aff0af0d5880769496c09a471b47ef98','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-3944','COBH-3944','db/changelog/changeset/0015_add_app_mobile_token/0015_changeSet.xml','2025-09-06 15:03:29',17,'EXECUTED','8:bf2bfebc2ec6a41e074c12364c2c9152','sqlFile; sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('DDO-64','DDO-64','db/changelog/changeset/0016_add_consultant_languages/0016_changeSet.xml','2025-09-06 15:03:29',18,'EXECUTED','8:dbac6662ad4dcb7a723ed63aef4dc0ae','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('DDO-85','DDO-85','db/changelog/changeset/0017_add_session_language/0017_changeSet.xml','2025-09-06 15:03:29',19,'EXECUTED','8:64e9446087efc05e3197634c47d0cd57','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('COBH-4158','COBH-4158','db/changelog/changeset/0018_add_2fa_encourage/0018_changeSet.xml','2025-09-06 15:03:29',20,'EXECUTED','8:11735e08f77c4ec84059273eee1e61bb','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('tenantId','aalicic','db/changelog/changeset/0019_tenant_id/0019_changeSet.xml','2025-09-06 15:03:29',21,'EXECUTED','8:2736d2fa783ebf9510e6dce5c4cc4427','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('OBI-138','OBI-138','db/changelog/changeset/0020_add_appointments/0020_changeSet.xml','2025-09-06 15:03:29',22,'EXECUTED','8:2ca8b6147ecb733d6e4ec1b43bfd293d','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('OBI-172','OBI-172','db/changelog/changeset/0021_index_for_consultant_search/0021_changeSet.xml','2025-09-06 15:03:29',23,'EXECUTED','8:e0310caa9bbdae1b9a1bff5d11c3d8eb','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('OBI-172','OBI-172','db/changelog/changeset/0022_delete_date_for_consultant_search/0022_changeSet.xml','2025-09-06 15:03:29',24,'EXECUTED','8:5d85d6c75c8cb00d291c0ea9f011f268','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('consultantStatus','aalicic','db/changelog/changeset/0023_consultant_status/0023_changeSet.xml','2025-09-06 15:03:29',25,'EXECUTED','8:0508c7e46cc30939a8f109ce40640c8a','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('consultantWalkThrough','aalicic','db/changelog/changeset/0024_consultant_walk_through/0024_changeSet.xml','2025-09-06 15:03:29',26,'EXECUTED','8:88c0eaea08b30d7053e5683f0aca6be2','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('OBI-408','OBI-408','db/changelog/changeset/0025_add_notify_enquiries_repeating/0025_changeSet.xml','2025-09-06 15:03:29',27,'EXECUTED','8:d08ed605fa32a1bc2a17fa6f373fd4f7','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('OBI-369','OBI-369','db/changelog/changeset/0026_add_notify_new_messages_from_advice_seeker/0026_changeSet.xml','2025-09-06 15:03:29',28,'EXECUTED','8:085be0dd0fd45628ec7cec2091bd61ec','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('consultantStatus','aalicic','db/changelog/changeset/0027_consultant_agency_status/0027_changeSet.xml','2025-09-06 15:03:29',29,'EXECUTED','8:6ebedd9f1d81a75c839a6ebb513c67e3','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('sessionMainTopic','tkuzynow','db/changelog/changeset/0028_session_main_topic/0028_changeSet.xml','2025-09-06 15:03:29',30,'EXECUTED','8:2f427e7485ba188d7678dde417494c77','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('sessionMainTopic','tkuzynow','db/changelog/changeset/0029_session_gender_and_age/0029_changeSet.xml','2025-09-06 15:03:29',31,'EXECUTED','8:666c8e087931b19564cb1c3dc0dc7f8a','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('sessionMainTopic','tkuzynow','db/changelog/changeset/0030_session_counsellingrelation_and_topics/0030_changeSet.xml','2025-09-06 15:03:29',32,'EXECUTED','8:3961a67011cca42d0315da03b84ddc8c','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('OBI-552','OBI-552','db/changelog/changeset/0031_add_preferred_language/0031_changeSet.xml','2025-09-06 15:03:29',33,'EXECUTED','8:5b692d7a9ecd966e676bc6b4301c8a12','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('VIC-284-chat-consulting-type-optional','patric-dosch-vi','db/changelog/changeset/0032_chat_consulting_type_optional/0032_changeSet.xml','2025-09-06 15:03:29',34,'EXECUTED','8:82f229e7a1f41f817a2fdac8ba84f959','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('VIC-838-chat-user-relation','patric-dosch-vi','db/changelog/changeset/0033_chat_add_user_chat_relation/0033_changeSet.xml','2025-09-06 15:03:29',35,'EXECUTED','8:ec6be7e23257a078e1ba93eb4bd208b5','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('OBI-650','OBI-650','db/changelog/changeset/0034_add_consultant_directly_set/0034_changeSet.xml','2025-09-06 15:03:29',36,'EXECUTED','8:37c9d29fe7857c0c07d83e114241bec1','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('VIC-2021','VIC-2021','db/changelog/changeset/0035_admin/0035_changeSet.xml','2025-09-06 15:03:29',37,'EXECUTED','8:f82e03b01494c84c86e8dbbfda1ae0ce','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('VIC-2021','idrissnaji','db/changelog/changeset/0036_index_for_admin_search/0036_changeSet.xml','2025-09-06 15:03:29',38,'EXECUTED','8:79ec7be9756bdad9875cdcaa4aec01d3','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('VIC-xxxx','aalicic','db/changelog/changeset/0037_user_confirmation_fields/0037_changeSet.xml','2025-09-06 15:03:29',39,'EXECUTED','8:0d221081891c4f9e1d6820908f8e0624','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('VIC-2252','aalicic','db/changelog/changeset/0038_consultant_confirmation_fields/0038_changeSet.xml','2025-09-06 15:03:29',40,'EXECUTED','8:b64a70464efb327c4c3f3ed053085a11','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('sessionMainTopicType','OBI','db/changelog/changeset/0039_session_main_topic_type/0039_changeSet.xml','2025-09-06 15:03:29',41,'EXECUTED','8:621b95375602028927c2f4b1c79162e9','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('addUserNotificationSettings','tkuzynow','db/changelog/changeset/0040_add_notification_settings/0040_changeSet.xml','2025-09-06 15:03:29',42,'EXECUTED','8:58343c965d75a2b6e1210dbe1f524c89','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('migrateUserNotificationSettings','tkuzynow','db/changelog/changeset/0041_migrate_notification_settings/0041_changeSet.xml','2025-09-06 15:03:29',43,'EXECUTED','8:c3d9606d45accbdc6dfeac1c0dd015f2','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('remove_session_monitoring_and_option','IoannisLafiotis','db/changelog/changeset/0042_remove_session_monitoring_and_option/0042_changeSet.xml','2025-09-06 15:03:29',44,'EXECUTED','8:0206790048e4caccafd49aed72c33565','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('migrateUserNotificationSettings','tkuzynow','db/changelog/changeset/0043_add_booking_id_to_appointment/0043_changeSet.xml','2025-09-06 15:03:29',45,'EXECUTED','8:00b480dde7bf7032d2fbdd3dbfb2c647','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('migrateUserNotificationSettings','tkuzynow','db/changelog/changeset/0044_add_referer_to_user/0044_changeSet.xml','2025-09-06 15:03:29',46,'EXECUTED','8:8929950a4598e810156142658f8b55f5','sqlFile','',NULL,'4.9.1',NULL,NULL,'7171008640'),
('migrateUserNotificationSettings','tkuzynow','db/changelog/changeset/0045_add_hint_and_create_date_to_chat/0045_changeSet.xml','2025-09-06 15:34:37',47,'EXECUTED','8:ee3f381e5bd033b63acda0ee5f269df5','sqlFile','',NULL,'4.9.1',NULL,NULL,'7172877548'),
('removeFeedbackRelatedColumns','leandroSilva','db/changelog/changeset/0046_remove_feeback_related_columns/0046_changeSet.xml','2025-10-26 11:02:31',48,'EXECUTED','8:993c04d8183c8c4dbf56ff7fcba3814a','sqlFile; sqlFile; sqlFile','',NULL,'4.9.1',NULL,NULL,'1476551342'),
('addMatrixPasswordColumn','caritas','db/changelog/changeset/0047_add_matrix_password/0047_changeSet.xml','2025-10-26 11:02:31',49,'EXECUTED','8:4971454cc3a92382468e233483b5c29c','sqlFile; sqlFile','',NULL,'4.9.1',NULL,NULL,'1476551342');
/*!40000 ALTER TABLE `DATABASECHANGELOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int(11) NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOGLOCK`
--

LOCK TABLES `DATABASECHANGELOGLOCK` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` DISABLE KEYS */;
INSERT INTO `DATABASECHANGELOGLOCK` VALUES
(1,'\0',NULL,NULL);
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `admin_id` varchar(36) NOT NULL,
  `tenant_id` bigint(21) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `type` varchar(6) NOT NULL,
  `rc_user_id` varchar(255) DEFAULT NULL,
  `id_old` bigint(21) DEFAULT NULL,
  `create_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `update_date` datetime NOT NULL DEFAULT utc_timestamp(),
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `idx_username_first_name_last_name_email` (`username`,`first_name`,`last_name`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES
('10792d02-8e8b-4cb2-98d6-338effab48b3',0,'bprayj','Brande','Pray','bprayj@dedecms.com','AGENCY','MZu8NpoSB',NULL,'2022-10-06 13:00:46','2022-05-06 04:02:31'),
('11103f67-b16b-42f7-b1c8-99061fcbba16',0,'bbaudic2f','Berri','Baudic','bbaudic2f@java.com','TENANT','KgFK3mBDw2F',NULL,'2022-11-12 18:43:37','2022-04-02 19:19:08'),
('1321383d-8f44-40d6-bc24-41bc37d8a20d',0,'hedgeond','Hakeem','Edgeon','hedgeond@miitbeian.gov.cn','SUPER','fdtjKz',NULL,'2022-09-21 16:27:15','2022-09-03 20:41:30'),
('13885432-21d8-4d4a-8c02-312d159ed635',0,'lballs26','Lucky','Balls','lballs26@nasa.gov','SUPER','azDK7zuzMW',NULL,'2022-02-12 15:17:31','2022-02-20 23:26:52'),
('164be67d-4d1b-4d80-bb6b-0ee057a1c59e',2,'byarnold3','Jeffy','Yarnold','byarnold3@discuz.net','AGENCY','CemSiLyUrKzX',NULL,'2022-01-11 16:02:30','2022-07-01 14:56:23'),
('16600ee7-2aef-469f-901e-87f1b202fe09',0,'mtreadwell20','Mariellen','Treadwell','mtreadwell20@loc.gov','TENANT','5atHTy',NULL,'2022-03-22 13:54:31','2022-10-02 02:24:24'),
('1cb9dc15-b817-441e-8070-64d770681acd',0,'closanoh','Carlene','Losano','closanoh@nbcnews.com','SUPER','r3YXo6r',NULL,'2022-09-29 20:49:52','2022-07-18 03:28:04'),
('1cc0fece-d83e-4729-aa2e-99217757a35b',0,'pklimpt1c','Polly','Klimpt','pklimpt1c@ca.gov','TENANT','rv4xdc1S5z',NULL,'2022-02-20 09:19:25','2022-02-01 16:43:10'),
('1d6072cf-ed88-4ec4-b4e6-0401d98dabfc',0,'istollenwerck2l','Isadore','Stollenwerck','istollenwerck2l@fc2.com','SUPER','ftUD0Tw5RkRr',NULL,'2022-10-06 10:25:46','2021-12-28 15:14:14'),
('1d8114f4-f45b-4ea9-a6c8-966b5ace3f46',0,'sneasam1k','Shayna','Neasam','sneasam1k@archive.org','TENANT','KmgvzYjdtF',NULL,'2022-09-25 17:50:21','2022-04-19 07:51:16'),
('1e82f788-d6ad-4ab7-ab1d-afd3119ea9ad',0,'dturner2k','Domenico','Turner','dturner2k@accuweather.com','SUPER','PvhEk1oL8IL',NULL,'2022-10-14 13:06:44','2022-07-13 12:53:42'),
('1f6e4bec-2929-4cbc-9073-e4a9757683d4',0,'cbriant1g','Cookie','Briant','cbriant1g@cnbc.com','SUPER','8FbOcxB',NULL,'2022-08-01 16:41:09','2022-06-19 03:06:29'),
('201b961d-51e9-4eff-8981-60d2a0edb6a8',1,'technical','Technical','User','technical@gmail.com','TENANT',NULL,NULL,'2025-11-19 02:00:47','2025-11-19 02:00:47'),
('2339d873-8155-4a00-a9be-3707e5f04c09',0,'qmcmychem4','Quincey','McMychem','qmcmychem4@mediafire.com','AGENCY','tdQ5LpvI7u',NULL,'2022-04-28 15:01:39','2022-02-04 22:23:05'),
('2b5e3a9f-ff69-4901-b4b9-7b99713a99b2',0,'twieldi','Thacher','Wield','twieldi@latimes.com','SUPER','oXIYmz7M',NULL,'2022-08-29 19:41:17','2022-08-19 11:37:56'),
('2d67737f-35b2-46f8-b938-aa674bcb862a',0,'dleyzell2j','Denny','Leyzell','dleyzell2j@ucsd.edu','TENANT','CVugh1SB8W',NULL,'2022-08-23 12:55:25','2022-04-19 01:25:40'),
('2ff0623e-32d9-49b5-820d-443e9e57e680',0,'ekrysztowczyk12','Egbert','Krysztowczyk','ekrysztowczyk12@omniture.com','AGENCY','rcXKJn0SmC',NULL,'2021-12-28 08:30:35','2022-05-26 04:32:02'),
('3463b29a-b882-4140-b260-58c4325561ce',0,'flamborneq','Flynn','Lamborne','flamborneq@walmart.com','TENANT','ANSgsoJqOP',NULL,'2022-05-22 07:54:21','2022-09-03 07:26:02'),
('382517bc-7b9d-4c44-8d33-6b8638201c98',2,'jcaseborne6','Jeffy','Caseborne','jcaseborne6@whitehouse.gov','TENANT','n8bAlPL9Ui',NULL,'2022-06-23 05:16:13','2022-01-19 04:48:18'),
('3d26cbfd-662e-4a45-be36-770e3acd007e',0,'dhuckle2i','Darnell','Huckle','dhuckle2i@slideshare.net','TENANT','BAKVcz3kUG',NULL,'2021-12-10 11:59:02','2022-06-21 19:03:17'),
('3f5fc28e-f3ff-4ac2-a7d4-afd548d7d903',0,'jscemp18','Jeanna','Scemp','jscemp18@altervista.org','SUPER','CdfjQolA',NULL,'2022-01-15 19:46:28','2022-07-07 19:54:05'),
('3fac8a86-6720-4fdc-ad3e-324222b27a8c',0,'efrancescuccio11','Eldridge','Francescuccio','efrancescuccio11@economist.com','SUPER','ItdmqEfh',NULL,'2022-01-09 23:34:17','2022-03-16 17:45:13'),
('4672410f-3533-4a79-94ae-e2056705e702',0,'hbuchetto','Hamil','Buchett','hbuchetto@yellowbook.com','AGENCY','a7T3j770',NULL,'2022-04-28 03:35:16','2022-06-29 07:33:01'),
('4cf7febb-8849-460f-8daf-d9fa83098ba9',0,'mionnisianm','Margarethe','Ionnisian','mionnisianm@meetup.com','TENANT','h4xnGCIyoE',NULL,'2022-05-17 11:10:44','2021-12-05 22:17:19'),
('4f7d7d85-7592-4a9e-8b68-cb319274c1e0',0,'bhackworthy9','Barn','Hackworthy','bhackworthy9@sourceforge.net','AGENCY','ODNw9Sg40QZa',NULL,'2022-02-17 04:31:22','2022-03-11 22:27:37'),
('53dde74b-fba4-414d-a140-a7634418dcf2',0,'baguirre1z','Brigham','Aguirre','baguirre1z@cpanel.net','SUPER','Mc4ACcSoYw',NULL,'2022-08-21 11:50:43','2022-03-25 09:16:53'),
('54bf976b-67ed-4a2a-a4b1-a0f30711ab09',0,'jdelaharpe2h','Jess','De la Harpe','jdelaharpe2h@imgur.com','AGENCY','fat6Xw',NULL,'2022-07-01 15:43:53','2021-12-17 02:54:52'),
('55c3d431-dbb4-4511-b76c-74bc33e7d9fd',0,'bmusk1l','Bunny','Musk','bmusk1l@biglobe.ne.jp','AGENCY','JRhOFCuOulG',NULL,'2022-10-25 17:16:11','2022-09-24 06:11:51'),
('5606179b-77e7-4056-aedc-68ddc769890c',0,'bmachin1j','Barn','Machin','bmachin1j@senate.gov','AGENCY','tKl4CM2',NULL,'2022-10-15 23:07:44','2022-01-29 12:57:38'),
('56b2dae4-5aed-467b-be3c-b3c1a5666b0e',0,'lsurcombe1t','Lauraine','Surcombe','lsurcombe1t@deliciousdays.com','SUPER','ojpeKIQP',NULL,'2022-08-07 09:53:38','2022-08-06 19:34:51'),
('57dfd011-56d5-4b34-98f4-2288a64f95ce',0,'lgoggin1x','Lusa','Goggin','lgoggin1x@nifty.com','TENANT','1e7EFoYq',NULL,'2022-01-11 23:20:28','2022-06-02 08:52:47'),
('5867fbb6-e0e8-4503-aeeb-df3e51ec4577',0,'kchewter28','Kary','Chewter','kchewter28@netlog.com','TENANT','F7DpCDaIqtWo',NULL,'2022-03-27 01:30:55','2022-01-09 22:08:47'),
('595ce81f-3449-45da-8740-6578f2a0f4d4',0,'struckell1e','Somerset','Truckell','struckell1e@prweb.com','SUPER','RN10adqNrk',NULL,'2022-08-02 08:55:02','2022-08-14 01:15:02'),
('5e835ff6-4729-4dc9-aa80-ee72e57c1771',0,'lbrakef','Levin','Brake','lbrakef@globo.com','SUPER','ai3j129gFmz',NULL,'2022-07-18 20:41:08','2022-01-01 10:09:46'),
('5ef61b7f-9e06-495d-bf95-37c4391e50e6',0,'oangood1u','Ogden','Angood','oangood1u@cnn.com','TENANT','yqOd36',NULL,'2022-06-17 03:24:43','2022-07-29 00:51:36'),
('647b9fa5-a50b-438a-9a8a-2008e25e718c',0,'acaldaroy','Angelia','Caldaro','acaldaroy@gnu.org','SUPER','FXwcfP',NULL,'2022-04-07 19:05:48','2022-03-24 07:27:59'),
('64edee24-ef71-4f16-8347-5f521e7c2807',0,'wwhoolehan7','Whittaker','Whoolehan','wwhoolehan7@webeden.co.uk','AGENCY','4jbftinN',NULL,'2022-02-04 08:09:52','2022-07-28 12:35:40'),
('6584f4a9-a7f0-42f0-b929-ab5c99c0802d',102,'cgenney5','Ceil','Genney','cgenney5@imageshack.us','TENANT','cVO6lHNCi',NULL,'2022-10-04 10:13:08','2022-01-03 03:14:00'),
('6b142b90-57a9-4872-a324-87dd2226039a',0,'gmarston2p','Glynis','Marston','gmarston2p@yolasite.com','TENANT','AMXHV9gVmpaw',NULL,'2022-01-21 20:03:57','2022-09-22 18:13:28'),
('6c034bd4-1039-440e-8bfa-1860647247ce',0,'jheineke24','James','Heineke','jheineke24@example.com','SUPER','0H7CL3q',NULL,'2022-04-18 10:14:21','2022-08-21 04:03:05'),
('6c6c83f8-f7fb-4289-8f9c-0f2b4f5c0a7d',0,'gkinrade1i','Gerhardine','Kinrade','gkinrade1i@squidoo.com','SUPER','AdZibIDqoP',NULL,'2021-12-07 18:48:01','2022-03-07 15:20:26'),
('6d15b3ff-2394-4d9f-9ea5-e958afe6a65c',2,'rstickells2','Jeffy','Stickells','rstickells2@eventbrite.com','AGENCY','nbaKmMyzG',NULL,'2022-01-01 22:52:43','2021-12-21 23:17:05'),
('7332e31c-f6fe-4ef4-a456-545949f223b5',0,'ltrusler17','Lilla','Trusler','ltrusler17@unc.edu','SUPER','9ccHrPk',NULL,'2022-03-15 11:47:46','2022-10-16 16:41:00'),
('7a091005-fab4-46ad-a556-8eddbbb6da20',0,'bbell1s','Bendix','Bell','bbell1s@blinklist.com','TENANT','bkIVOtDm',NULL,'2022-09-05 20:53:45','2022-06-25 14:22:42'),
('7ad454de-cf29-4557-b8b3-1bf986524de2',1,'apau1','Jeffy','Pau','apau1@nymag.com','AGENCY','xKAefvo',NULL,'2022-01-24 23:11:29','2022-04-10 22:47:34'),
('7b1e15fe-4039-4ce7-a078-05996ff06676',0,'nbaile8','Nannette','Baile','nbaile8@utexas.edu','TENANT','qkjfX8lMMqX',NULL,'2022-07-03 15:34:23','2022-07-27 19:53:34'),
('7b43fa6b-176f-4cd0-be80-45adc03b0817',0,'idunford22','Isa','Dunford','idunford22@soundcloud.com','AGENCY','dA2uKb',NULL,'2022-05-29 19:56:16','2022-07-29 01:10:43'),
('7e092a92-35ae-4ab8-9de6-aeeae4cda702',0,'saim2d','Saunderson','Aim','saim2d@seattletimes.com','SUPER','0upvw62neeD',NULL,'2022-10-10 20:59:24','2022-05-03 21:39:26'),
('7e7d8af8-2b45-48a3-8bdb-359d082d557d',0,'cstickell','Cora','Stickel','cstickell@live.com','TENANT','pKyxziiZ',NULL,'2022-02-16 04:32:37','2021-12-11 18:37:20'),
('7f987f11-255a-4455-b24a-e3766d6c3696',0,'mdoctor2r','Mike','Doctor','mdoctor2r@bizjournals.com','TENANT','tu6LtD02vd0M',NULL,'2022-01-17 22:54:12','2022-01-20 21:10:33'),
('8170f72a-40ef-4a14-bf3a-ad52a6ce20d0',0,'lmordeyc','Ludvig','Mordey','lmordeyc@parallels.com','AGENCY','nH5zepMffY',NULL,'2022-08-28 09:25:36','2022-05-09 06:29:20'),
('84cb8696-992e-498f-97da-f7e31a65a442',0,'lfrewk','Lorine','Frew','lfrewk@telegraph.co.uk','AGENCY','ICnCwOpYBj',NULL,'2022-11-23 10:48:48','2022-11-25 04:35:49'),
('85c8cab9-fd43-41a1-9c69-dfd8b4a26dea',0,'lway1a','Linzy','Way','lway1a@yahoo.co.jp','SUPER','OjzfrJ',NULL,'2022-10-17 10:59:38','2021-12-07 01:59:44'),
('87073685-c4cf-4f91-a77f-938028af2c3d',0,'lstowers21','Lennie','Stowers','lstowers21@purevolume.com','TENANT','t6SacEcaxqM',NULL,'2022-10-09 17:32:56','2022-04-21 19:25:53'),
('8b549d79-28c4-400f-b28d-f64868627cdd',0,'trodgman2b','Thaddus','Rodgman','trodgman2b@plala.or.jp','SUPER','kGA7nnhyDxjp',NULL,'2022-02-05 07:03:49','2022-01-18 07:51:48'),
('8ba046eb-bc58-4f73-90c4-dcfeace52edf',0,'pgamlyn1r','Pete','Gamlyn','pgamlyn1r@amazon.co.uk','TENANT','5FA9Ih1Mk',NULL,'2022-07-23 10:25:29','2022-03-21 09:02:52'),
('8d10194c-6c38-4975-9368-c0f6497dcefd',0,'bshortou','Bessy','Shorto','bshortou@photobucket.com','AGENCY','QFx7uyKZ',NULL,'2022-01-08 20:52:05','2022-06-19 00:39:51'),
('8e465f82-5c0f-483a-b500-b3b2074dd001',0,'mtarpey1v','Merle','Tarpey','mtarpey1v@zimbio.com','SUPER','DVEODtx5EcB',NULL,'2022-08-11 23:58:46','2022-03-28 17:39:46'),
('90d1e6a7-7171-4145-b1e4-61e70fbea5dd',0,'dbeat16','Deina','Beat','dbeat16@berkeley.edu','TENANT','1yZ46Z0KacK',NULL,'2022-06-13 14:01:45','2022-05-08 20:10:19'),
('951f933d-e54a-4091-8f15-f62b9f0fa9bb',0,'eoretw','Elysha','Oret','eoretw@oakley.com','SUPER','x7kgiXO',NULL,'2022-01-26 21:30:47','2022-03-17 06:30:30'),
('96627f23-1586-47eb-8b99-32191d5c13fa',0,'cpattillo25','Casi','Pattillo','cpattillo25@taobao.com','TENANT','mAI2kVvVMY',NULL,'2022-02-16 00:20:54','2022-04-18 09:35:43'),
('96fc748c-aeb3-45db-a50d-114c07feacce',0,'lbroinlich27','Lexy','Broinlich','lbroinlich27@gizmodo.com','TENANT','Ol3TeBY',NULL,'2021-12-04 11:14:38','2022-04-21 10:55:04'),
('98dc41bc-42db-4c04-aa8b-fec174ff412a',0,'lomalley15','Lemmie','O\'Malley','lomalley15@digg.com','SUPER','0R7rUc',NULL,'2022-06-04 11:38:21','2022-11-08 14:20:18'),
('9fb9dd39-0990-4516-a847-13f713493722',0,'mdimondp','Maurene','Dimond','mdimondp@4shared.com','SUPER','DhGP5DRZ',NULL,'2022-05-17 03:13:20','2022-06-03 21:06:01'),
('a13a9abc-b985-4d9d-970a-18c954759dae',0,'ceyckelbeck1p','Cleo','Eyckelbeck','ceyckelbeck1p@home.pl','TENANT','3jTQrqgc7x',NULL,'2022-10-31 01:48:19','2022-07-08 05:42:46'),
('a2b914b0-3722-4e04-acf6-86846f785e37',0,'jvlasin2e','Jasper','Vlasin','jvlasin2e@mediafire.com','TENANT','CbXlg83rep',NULL,'2022-02-07 07:32:17','2022-01-02 03:51:30'),
('a5729dc1-9ad5-498a-a1b7-47650fa89b8e',0,'rhaverson1y','Robb','Haverson','rhaverson1y@upenn.edu','SUPER','3nceQflghD7',NULL,'2022-04-28 22:04:20','2022-08-26 05:00:10'),
('a63051b4-dd05-4635-8734-62c612c21739',0,'gcrispe1q','Germayne','Crispe','gcrispe1q@over-blog.com','TENANT','1v1A92BRUW',NULL,'2022-02-03 00:59:07','2022-07-29 00:22:30'),
('a67cebb4-c246-4ad7-8f2c-4318c973a300',0,'tmccaffertyg','Tera','McCafferty','tmccaffertyg@cnet.com','AGENCY','vch4Zc',NULL,'2022-10-20 04:27:45','2021-12-05 06:08:21'),
('a7d9548b-ce8b-4643-9f9e-5c6d8a28164d',0,'ebenzi2m','Eberhard','Benzi','ebenzi2m@github.com','SUPER','Tl0TI8P',NULL,'2022-09-24 11:07:14','2022-02-04 18:10:10'),
('a86ab999-262f-4061-9512-033940ce8e17',0,'emacwilliame','Ebony','MacWilliam','emacwilliame@arstechnica.com','TENANT','nabJkwul',NULL,'2022-09-30 20:39:49','2022-11-01 19:07:01'),
('aa3be4a9-6242-4161-867f-33fc122993e3',0,'lwasbrought','Lilli','Wasbrough','lwasbrought@yellowpages.com','SUPER','EJK1iqL',NULL,'2022-10-07 14:34:13','2022-10-07 07:40:17'),
('b035e920-45ff-4c7b-b717-e5bfcb23f653',0,'lupshall1h','Lethia','Upshall','lupshall1h@privacy.gov.au','SUPER','tsxc5T9DSNQ7',NULL,'2022-05-12 04:47:16','2022-01-06 13:20:28'),
('b297d37d-e281-4188-b74b-db36bb71c34e',0,'rrobertucci1f','Rhodie','Robertucci','rrobertucci1f@wordpress.com','AGENCY','jCCa5FT',NULL,'2022-09-01 03:56:22','2021-12-06 10:02:26'),
('b2da7ebf-058b-4280-a3ee-5d797a7ccce2',0,'orojahn1w','Odella','Rojahn','orojahn1w@census.gov','AGENCY','2c8efuGKSU',NULL,'2022-11-23 19:04:48','2022-10-28 00:02:59'),
('b3727243-bcd6-4376-bddd-c4cabb9a907b',0,'lfinlryb','Lita','Finlry','lfinlryb@squidoo.com','TENANT','ohExQG',NULL,'2022-11-20 09:01:06','2022-06-23 04:21:21'),
('b4b6c19d-2733-40eb-be5e-a16280be58bc',0,'sguiettz','Sully','Guiett','sguiettz@delicious.com','AGENCY','19rgbYsRLE',NULL,'2022-05-02 07:42:24','2021-12-12 17:17:29'),
('b4fd870e-95cb-4b5c-9d24-99757d220a72',0,'sedghinn1b','Sheff','Edghinn','sedghinn1b@examiner.com','SUPER','Lw98Wy',NULL,'2021-12-23 00:54:41','2022-04-29 02:55:30'),
('b5de71d6-e6b9-4fdb-a338-52685d5fd052',0,'mboddie1o','Merline','Boddie','mboddie1o@ovh.net','AGENCY','iYOzi8vnox',NULL,'2022-03-04 09:47:37','2021-12-08 21:01:38'),
('bb9aed91-a06a-4f99-a56c-a3f0524e6281',0,'sstockingn','Sander','Stocking','sstockingn@g.co','TENANT','y2c2ADk4vAQ',NULL,'2022-03-15 04:08:57','2022-05-07 21:44:00'),
('bbe47746-0379-4fa3-94f5-041c62a5c7b7',0,'lbromwichr','Larry','Bromwich','lbromwichr@utexas.edu','AGENCY','LTB49E',NULL,'2022-03-19 09:11:39','2022-02-26 05:14:45'),
('bc062e2c-174c-474f-8725-c0a6c9478c7d',0,'ckaasmann23','Carissa','Kaasmann','ckaasmann23@geocities.com','TENANT','em73jyUTA',NULL,'2022-03-18 13:43:38','2021-12-08 05:16:23'),
('bdaabcf1-49da-4f68-bc6b-60ec5054820a',0,'fchesnuts','Flint','Chesnut','fchesnuts@bluehost.com','TENANT','OdRvmjvcl8q',NULL,'2022-01-06 20:51:58','2022-07-28 03:04:25'),
('cad5b4c1-fc3d-48c4-a6ad-79d00beb1c15',0,'lswateridgex','Lorrie','Swateridge','lswateridgex@unicef.org','TENANT','M6RTnQru',NULL,'2022-04-02 17:14:42','2022-03-04 12:05:48'),
('d198cfcd-921d-4f2f-8954-e7ba91425c87',0,'wbecraft1m','Wolfgang','Becraft','wbecraft1m@amazonaws.com','AGENCY','BOt7fRHiP',NULL,'2022-05-22 06:57:26','2021-12-04 16:38:56'),
('d42c2e5e-143c-4db1-a90f-7cccf82fbb15',0,'ofarragher0','Olvan','Farragher','ofarragher0@vk.com','AGENCY','z4TkzduI',NULL,'2021-12-21 23:14:03','2021-12-02 16:15:56'),
('d498e192-c393-4162-ab1d-da6564747d9d',0,'jbernardoni13','Jarib','Bernardoni','jbernardoni13@artisteer.com','SUPER','dxENKq',NULL,'2022-02-15 01:47:49','2021-12-14 13:35:54'),
('d8bda876-d9b5-46d0-88f5-4264d6095595',0,'rwynter14','Roi','Wynter','rwynter14@disqus.com','AGENCY','s0vGpl',NULL,'2022-03-10 13:42:12','2021-11-30 16:57:01'),
('d988b4ef-7c23-4ba8-a4e1-c182580e3ed5',0,'mcarryer1d','Mattie','Carryer','mcarryer1d@purevolume.com','TENANT','9J08pmg',NULL,'2022-03-15 03:12:00','2022-06-18 06:33:52'),
('dc18fabe-c0bf-442a-ae35-a870cd88bb00',0,'averonique1n','Andonis','Veronique','averonique1n@omniture.com','SUPER','QPzwe7O5T1',NULL,'2022-05-12 04:03:20','2022-01-12 21:14:33'),
('e0d9e48f-a377-4863-a5c9-9b0c81af5a3f',0,'tpray10','Tiphany','Pray','tpray10@chronoengine.com','SUPER','jWUJZ2bmH8PW',NULL,'2022-05-09 21:40:42','2022-11-10 06:04:30'),
('e15e4dff-7a0d-49c6-9c13-11c39ee35053',0,'rmacdavitt2c','Raoul','MacDavitt','rmacdavitt2c@sohu.com','SUPER','PJOI71',NULL,'2022-08-22 11:42:56','2022-05-28 00:53:45'),
('e60d9f21-ef03-4eeb-a2c6-8b0dce4e1d50',0,'owithrington2o','Odelinda','Withrington','owithrington2o@ed.gov','SUPER','LcIyZfV0P7',NULL,'2022-11-24 11:26:32','2022-06-18 20:51:36'),
('e8097387-13ae-4042-a949-afb09f8351d1',0,'kcoffelt2q','Koren','Coffelt','kcoffelt2q@opensource.org','SUPER','p8HI0E73z',NULL,'2022-10-14 02:34:36','2022-07-01 01:40:50'),
('ed927ee8-4b0d-4e28-8ad2-3e68d1990e5f',0,'epughsley19','Evita','Pughsley','epughsley19@miitbeian.gov.cn','SUPER','aOihct4la',NULL,'2022-09-01 02:17:09','2022-04-03 06:32:02'),
('ee88be00-4762-47b7-ae30-351398e759f1',0,'jcartmailv','Joachim','Cartmail','jcartmailv@samsung.com','SUPER','L9LQmDHmu',NULL,'2022-09-09 11:21:03','2021-12-08 07:03:20'),
('ef53c589-3367-45f9-88da-de6d3a6e15ff',0,'dbeverage2n','Ddene','Beverage','dbeverage2n@biglobe.ne.jp','TENANT','TuoxX5f',NULL,'2022-07-18 12:38:24','2022-06-14 00:31:31'),
('f635e82c-4b77-452b-989b-a8c01553f789',0,'gblindmann29','Guinna','Blindmann','gblindmann29@vkontakte.ru','TENANT','ZMDwoXX1cLz',NULL,'2021-12-01 13:11:25','2022-10-19 12:30:33'),
('faaf0cc8-54b6-4c94-9f8e-454217596180',0,'wsygrovesa','Warden','Sygroves','wsygrovesa@squidoo.com','AGENCY','nz5cl0e',NULL,'2022-01-14 14:33:17','2022-08-24 16:38:54'),
('ff46488b-ac2a-4042-8752-e0f6dc722b84',0,'ppithcock2g','Pammy','Pithcock','ppithcock2g@umich.edu','SUPER','F8znYd',NULL,'2022-01-24 17:40:39','2022-06-19 01:35:13'),
('ffd5244d-29c6-4b6f-9e07-fe6a158fb376',0,'fnowell2a','Frederich','Nowell','fnowell2a@icq.com','TENANT','hYqrgS',NULL,'2021-12-06 02:56:10','2021-12-06 05:14:06');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_agency`
--

DROP TABLE IF EXISTS `admin_agency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_agency` (
  `id` bigint(21) unsigned NOT NULL,
  `admin_id` varchar(36) NOT NULL,
  `agency_id` bigint(21) unsigned NOT NULL,
  `create_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `update_date` datetime NOT NULL DEFAULT utc_timestamp(),
  PRIMARY KEY (`id`),
  KEY `admin_id` (`admin_id`),
  CONSTRAINT `admin_agency_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_agency`
--

LOCK TABLES `admin_agency` WRITE;
/*!40000 ALTER TABLE `admin_agency` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_agency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointment` (
  `id` char(36) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `description` varchar(300) DEFAULT NULL,
  `status` varchar(7) NOT NULL,
  `consultant_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `appointment_consultant_constraint` (`consultant_id`),
  CONSTRAINT `appointment_consultant_constraint` FOREIGN KEY (`consultant_id`) REFERENCES `consultant` (`consultant_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat`
--

DROP TABLE IF EXISTS `chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat` (
  `id` bigint(21) unsigned NOT NULL,
  `topic` varchar(255) NOT NULL,
  `consulting_type` tinyint(4) unsigned DEFAULT NULL,
  `initial_start_date` datetime NOT NULL,
  `start_date` datetime NOT NULL,
  `duration` smallint(6) NOT NULL,
  `is_repetitive` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `chat_interval` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `max_participants` tinyint(4) unsigned DEFAULT NULL,
  `consultant_id_owner` varchar(36) NOT NULL,
  `rc_group_id` varchar(255) DEFAULT NULL,
  `update_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `create_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `hint_message` varchar(300) DEFAULT NULL,
  `matrix_room_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `consultant_id_owner` (`consultant_id_owner`),
  CONSTRAINT `chat_consultant_ibfk_1` FOREIGN KEY (`consultant_id_owner`) REFERENCES `consultant` (`consultant_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat`
--

LOCK TABLES `chat` WRITE;
/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`userservice`@`%`*/ /*!50003 TRIGGER `userservice`.`chat_update` BEFORE UPDATE ON `userservice`.`chat` FOR EACH ROW BEGIN
set new.update_date=utc_timestamp();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `chat_agency`
--

DROP TABLE IF EXISTS `chat_agency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_agency` (
  `id` bigint(21) unsigned NOT NULL,
  `chat_id` bigint(21) unsigned NOT NULL,
  `agency_id` bigint(21) unsigned NOT NULL,
  `create_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `update_date` datetime NOT NULL DEFAULT utc_timestamp(),
  PRIMARY KEY (`id`),
  KEY `chat_id` (`chat_id`),
  CONSTRAINT `chat_agency_ibfk_1` FOREIGN KEY (`chat_id`) REFERENCES `chat` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_agency`
--

LOCK TABLES `chat_agency` WRITE;
/*!40000 ALTER TABLE `chat_agency` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_agency` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`userservice`@`%`*/ /*!50003 TRIGGER `userservice`.`chat_agency_update` BEFORE UPDATE ON `userservice`.`chat_agency` FOR EACH ROW BEGIN
set new.update_date=utc_timestamp();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `consultant`
--

DROP TABLE IF EXISTS `consultant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultant` (
  `consultant_id` varchar(36) NOT NULL,
  `tenant_id` bigint(21) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `is_team_consultant` tinyint(4) unsigned NOT NULL DEFAULT 0,
  `is_absent` tinyint(4) unsigned NOT NULL DEFAULT 0,
  `absence_message` longtext DEFAULT NULL,
  `rc_user_id` varchar(255) DEFAULT NULL,
  `matrix_user_id` varchar(255) DEFAULT NULL,
  `language_formal` tinyint(4) NOT NULL DEFAULT 1,
  `data_privacy_confirmation` datetime DEFAULT NULL,
  `terms_and_conditions_confirmation` datetime DEFAULT NULL,
  `language_code` varchar(2) NOT NULL DEFAULT 'de',
  `encourage_2fa` bit(1) NOT NULL DEFAULT b'1',
  `notify_enquiries_repeating` bit(1) NOT NULL DEFAULT b'1',
  `notify_new_chat_message_from_advice_seeker` bit(1) NOT NULL DEFAULT b'1',
  `status` varchar(11) DEFAULT NULL,
  `walk_through_enabled` tinyint(4) NOT NULL DEFAULT 1,
  `id_old` bigint(21) DEFAULT NULL,
  `delete_date` datetime DEFAULT NULL,
  `create_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `update_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `notifications_enabled` tinyint(4) unsigned NOT NULL DEFAULT 0,
  `notifications_settings` varchar(4000) DEFAULT '',
  `matrix_password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`consultant_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `idx_first_name_last_name_email_delete_date` (`first_name`,`last_name`,`email`,`delete_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultant`
--

LOCK TABLES `consultant` WRITE;
/*!40000 ALTER TABLE `consultant` DISABLE KEYS */;
INSERT INTO `consultant` VALUES
('12d455a9-bd17-4da7-bcf6-a86fe1738520',1,'enc.NZSXMZLSMV3GK4RRGIZQ....','neverever123','neverever123','neverever123@gmail.com',0,0,NULL,'dummy-rc','@neverever123:91.99.219.182',1,NULL,NULL,'de','','','','CREATED',1,NULL,NULL,'2025-12-17 07:32:56','2025-12-17 07:32:57',1,'{\"initialEnquiryNotificationEnabled\":true,\"newChatMessageNotificationEnabled\":true,\"reassignmentNotificationEnabled\":true,\"appointmentNotificationEnabled\":true}','@Suchtberatung1'),
('ed66f795-8746-4c25-ab7e-b5d2356e9878',1,'enc.MZZGC3TLL5ZGC5DHMVRGK4Q.','frank','ratgeber','frank_ratgeber@gmail.com',0,0,NULL,'dummy-rc',NULL,1,NULL,NULL,'de','','','','CREATED',1,NULL,NULL,'2025-12-17 07:26:22','2025-12-17 07:26:23',1,'{\"initialEnquiryNotificationEnabled\":true,\"newChatMessageNotificationEnabled\":true,\"reassignmentNotificationEnabled\":true,\"appointmentNotificationEnabled\":true}','@Suchtberatung1');
/*!40000 ALTER TABLE `consultant` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`userservice`@`%`*/ /*!50003 TRIGGER `userservice`.`consultant_update` BEFORE UPDATE ON `userservice`.`consultant` FOR EACH ROW BEGIN
set new.update_date=utc_timestamp();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `consultant_agency`
--

DROP TABLE IF EXISTS `consultant_agency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultant_agency` (
  `id` bigint(21) unsigned NOT NULL,
  `tenant_id` bigint(21) DEFAULT NULL,
  `consultant_id` varchar(36) NOT NULL,
  `agency_id` bigint(21) unsigned NOT NULL,
  `create_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `update_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `delete_date` datetime DEFAULT NULL,
  `status` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `consultant_id` (`consultant_id`),
  CONSTRAINT `consultant_agency_ibfk_1` FOREIGN KEY (`consultant_id`) REFERENCES `consultant` (`consultant_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultant_agency`
--

LOCK TABLES `consultant_agency` WRITE;
/*!40000 ALTER TABLE `consultant_agency` DISABLE KEYS */;
INSERT INTO `consultant_agency` VALUES
(100339,1,'ed66f795-8746-4c25-ab7e-b5d2356e9878',179,'2025-12-17 07:26:23','2025-12-17 07:26:23',NULL,'CREATED'),
(100340,1,'12d455a9-bd17-4da7-bcf6-a86fe1738520',179,'2025-12-17 07:32:57','2025-12-17 07:32:57',NULL,'CREATED');
/*!40000 ALTER TABLE `consultant_agency` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`userservice`@`%`*/ /*!50003 TRIGGER `userservice`.`consultant_agency_update` BEFORE UPDATE ON `userservice`.`consultant_agency` FOR EACH ROW BEGIN
set new.update_date=utc_timestamp();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `consultant_mobile_token`
--

DROP TABLE IF EXISTS `consultant_mobile_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultant_mobile_token` (
  `id` bigint(21) unsigned NOT NULL,
  `consultant_id` varchar(36) NOT NULL,
  `mobile_app_token` longtext NOT NULL,
  `create_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `update_date` datetime NOT NULL DEFAULT utc_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobile_app_token` (`mobile_app_token`) USING HASH,
  KEY `consultant_id` (`consultant_id`),
  CONSTRAINT `consultant_mobile_token_ibfk_1` FOREIGN KEY (`consultant_id`) REFERENCES `consultant` (`consultant_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultant_mobile_token`
--

LOCK TABLES `consultant_mobile_token` WRITE;
/*!40000 ALTER TABLE `consultant_mobile_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `consultant_mobile_token` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`userservice`@`%`*/ /*!50003 TRIGGER `userservice`.`consultant_mobile_token_update`
    BEFORE UPDATE ON `userservice`.`consultant_mobile_token`
    FOR EACH ROW BEGIN set new.update_date=utc_timestamp();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `group_chat_participant`
--

DROP TABLE IF EXISTS `group_chat_participant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_chat_participant` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `chat_id` bigint(20) unsigned NOT NULL,
  `consultant_id` varchar(36) NOT NULL,
  `joined_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_chat_consultant` (`chat_id`,`consultant_id`),
  KEY `idx_consultant` (`consultant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=255 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_chat_participant`
--

LOCK TABLES `group_chat_participant` WRITE;
/*!40000 ALTER TABLE `group_chat_participant` DISABLE KEYS */;
INSERT INTO `group_chat_participant` VALUES
(82,101617,'3eb87875-d58d-4a33-b182-6ff7c7db0acc','2025-11-23 03:22:59'),
(83,101617,'15f7b184-f85e-4c9c-af98-e96066e4cb9f','2025-11-23 03:22:59'),
(84,101617,'bebb4399-fda2-4bef-8fd9-e89f276e3e1d','2025-11-23 03:23:00'),
(85,101618,'3eb87875-d58d-4a33-b182-6ff7c7db0acc','2025-11-23 03:36:38'),
(86,101618,'bebb4399-fda2-4bef-8fd9-e89f276e3e1d','2025-11-23 03:36:38'),
(87,101618,'15f7b184-f85e-4c9c-af98-e96066e4cb9f','2025-11-23 03:36:39'),
(88,101619,'3eb87875-d58d-4a33-b182-6ff7c7db0acc','2025-11-23 03:54:41'),
(89,101619,'bebb4399-fda2-4bef-8fd9-e89f276e3e1d','2025-11-23 03:54:42'),
(90,101619,'15f7b184-f85e-4c9c-af98-e96066e4cb9f','2025-11-23 03:54:42'),
(91,101620,'3eb87875-d58d-4a33-b182-6ff7c7db0acc','2025-11-23 04:01:03'),
(92,101620,'bebb4399-fda2-4bef-8fd9-e89f276e3e1d','2025-11-23 04:01:04'),
(93,101620,'15f7b184-f85e-4c9c-af98-e96066e4cb9f','2025-11-23 04:01:04'),
(98,101624,'15f7b184-f85e-4c9c-af98-e96066e4cb9f','2025-11-23 05:01:13'),
(99,101624,'bebb4399-fda2-4bef-8fd9-e89f276e3e1d','2025-11-23 05:01:13'),
(102,101626,'15f7b184-f85e-4c9c-af98-e96066e4cb9f','2025-11-23 05:15:41'),
(103,101626,'bebb4399-fda2-4bef-8fd9-e89f276e3e1d','2025-11-23 05:15:42'),
(105,101627,'15f7b184-f85e-4c9c-af98-e96066e4cb9f','2025-11-23 05:46:11'),
(106,101627,'bebb4399-fda2-4bef-8fd9-e89f276e3e1d','2025-11-23 05:46:11'),
(115,101636,'15f7b184-f85e-4c9c-af98-e96066e4cb9f','2025-11-23 06:57:27'),
(116,101636,'bebb4399-fda2-4bef-8fd9-e89f276e3e1d','2025-11-23 06:57:27'),
(117,84,'66923d95-156c-4f9f-bf63-f5e6c8caba06','2025-11-23 08:35:27'),
(118,101638,'bebb4399-fda2-4bef-8fd9-e89f276e3e1d','2025-11-23 08:35:27'),
(119,101638,'15f7b184-f85e-4c9c-af98-e96066e4cb9f','2025-11-23 08:35:27'),
(120,85,'8300f07c-598d-4c69-918b-c524bc946d95','2025-11-24 03:23:09'),
(121,101639,'fad59d0e-434f-4b1a-b5d6-594dbd403157','2025-11-24 03:23:10'),
(122,101639,'7f8aed80-12a7-4fd6-a5a4-feb301a5f6db','2025-11-24 03:23:10'),
(123,101639,'41da885d-50c6-4e00-afc5-cdf74ac857c3','2025-11-24 03:23:11'),
(124,101639,'6a2d7786-821d-4819-b42b-938a5ec17f77','2025-11-24 03:23:11'),
(125,86,'8300f07c-598d-4c69-918b-c524bc946d95','2025-11-24 10:25:52'),
(126,101642,'fad59d0e-434f-4b1a-b5d6-594dbd403157','2025-11-24 10:25:53'),
(127,101642,'6a2d7786-821d-4819-b42b-938a5ec17f77','2025-11-24 10:25:53'),
(128,101642,'41da885d-50c6-4e00-afc5-cdf74ac857c3','2025-11-24 10:25:53'),
(129,87,'8300f07c-598d-4c69-918b-c524bc946d95','2025-11-24 14:03:26'),
(130,101647,'7b617e55-f146-4dd1-95ac-a0ad6e0d42e8','2025-11-24 14:03:26'),
(131,88,'9a0478cc-fb0c-481a-b0a9-297fa6579f63','2025-11-25 12:56:48'),
(132,101655,'a95a67c7-4323-4a9e-94bd-4ca1ff08ad9d','2025-11-25 12:56:49'),
(133,89,'9a0478cc-fb0c-481a-b0a9-297fa6579f63','2025-11-26 07:01:39'),
(134,101656,'a95a67c7-4323-4a9e-94bd-4ca1ff08ad9d','2025-11-26 07:01:40'),
(135,101656,'55c2fb0b-9be9-4387-a84d-7babf1230d6e','2025-11-26 07:01:40'),
(136,90,'43f2e956-432a-4b4c-8835-3fc8331aa0a3','2025-11-27 10:11:12'),
(137,101657,'127668be-9bda-4682-bf0c-e406c7fc6802','2025-11-27 10:11:13'),
(138,101657,'b259712f-c1b9-412a-ba76-f8d56b767a8d','2025-11-27 10:11:13'),
(139,101657,'60ad6f69-53b7-48f6-a848-488cbb098150','2025-11-27 10:11:14'),
(140,101657,'21750a61-d6b2-4031-a427-78299ddf5eab','2025-11-27 10:11:14'),
(141,91,'5a9f8d29-b03a-4d05-9245-79df59346d9f','2025-11-27 10:54:57'),
(142,101658,'cac5d29e-bebb-488f-b1a8-f787d9493683','2025-11-27 10:54:57'),
(143,92,'127668be-9bda-4682-bf0c-e406c7fc6802','2025-11-27 13:20:19'),
(144,101659,'43f2e956-432a-4b4c-8835-3fc8331aa0a3','2025-11-27 13:20:19'),
(145,101659,'b259712f-c1b9-412a-ba76-f8d56b767a8d','2025-11-27 13:20:20'),
(146,101659,'60ad6f69-53b7-48f6-a848-488cbb098150','2025-11-27 13:20:20'),
(147,101659,'21750a61-d6b2-4031-a427-78299ddf5eab','2025-11-27 13:20:20'),
(148,101659,'e9d76c22-7535-45ad-ab6d-93fdea16d7ca','2025-11-27 13:20:20'),
(149,101659,'5a9f8d29-b03a-4d05-9245-79df59346d9f','2025-11-27 13:20:20'),
(150,101659,'cac5d29e-bebb-488f-b1a8-f787d9493683','2025-11-27 13:20:21'),
(151,93,'43f2e956-432a-4b4c-8835-3fc8331aa0a3','2025-11-28 09:46:06'),
(152,101660,'60ad6f69-53b7-48f6-a848-488cbb098150','2025-11-28 09:46:06'),
(153,101660,'127668be-9bda-4682-bf0c-e406c7fc6802','2025-11-28 09:46:07'),
(154,94,'b259712f-c1b9-412a-ba76-f8d56b767a8d','2025-12-03 15:23:40'),
(155,101661,'60ad6f69-53b7-48f6-a848-488cbb098150','2025-12-03 15:23:40'),
(156,101661,'21750a61-d6b2-4031-a427-78299ddf5eab','2025-12-03 15:23:41'),
(157,101661,'cac5d29e-bebb-488f-b1a8-f787d9493683','2025-12-03 15:23:41'),
(158,95,'5ec83a2d-4cf3-48f8-ad5a-01123644d789','2025-12-06 10:24:23'),
(159,101667,'8865f509-4ba7-4185-8fc1-b6a03a021298','2025-12-06 10:24:23'),
(160,101667,'374bb3f0-d1bf-44f0-80ea-6322867c7ecb','2025-12-06 10:24:24'),
(161,96,'9b14447a-3713-4a57-9029-e407b75e46d7','2025-12-07 11:59:29'),
(162,101672,'b6450052-fc57-4746-8a6d-a3dff995917a','2025-12-07 11:59:30'),
(163,101672,'c9f2cd61-b185-4e09-860b-8a1eafebc427','2025-12-07 11:59:30'),
(164,97,'9b14447a-3713-4a57-9029-e407b75e46d7','2025-12-07 14:05:27'),
(165,101673,'b6450052-fc57-4746-8a6d-a3dff995917a','2025-12-07 14:05:27'),
(166,98,'1e07eff6-272d-4473-97ad-ba134e9e4002','2025-12-09 10:52:41'),
(167,101678,'89318b9a-8d70-46ac-b704-c47d0cda331b','2025-12-09 10:52:42'),
(168,101678,'7c941eb9-9379-439e-96ea-78a0fcb9d48e','2025-12-09 10:52:42'),
(169,101678,'75ca4786-6bc8-484f-88a1-611758e58909','2025-12-09 10:52:43'),
(170,99,'1e07eff6-272d-4473-97ad-ba134e9e4002','2025-12-10 14:39:01'),
(171,101683,'75ca4786-6bc8-484f-88a1-611758e58909','2025-12-10 14:39:02'),
(172,101683,'89318b9a-8d70-46ac-b704-c47d0cda331b','2025-12-10 14:39:02'),
(173,101683,'7c941eb9-9379-439e-96ea-78a0fcb9d48e','2025-12-10 14:39:02'),
(174,100,'60ad6f69-53b7-48f6-a848-488cbb098150','2025-12-10 15:21:14'),
(175,101686,'43f2e956-432a-4b4c-8835-3fc8331aa0a3','2025-12-10 15:21:14'),
(176,101686,'21750a61-d6b2-4031-a427-78299ddf5eab','2025-12-10 15:21:15'),
(177,101686,'cac5d29e-bebb-488f-b1a8-f787d9493683','2025-12-10 15:21:15'),
(178,101,'cac5d29e-bebb-488f-b1a8-f787d9493683','2025-12-10 15:29:12'),
(179,101688,'43f2e956-432a-4b4c-8835-3fc8331aa0a3','2025-12-10 15:29:12'),
(180,101688,'b259712f-c1b9-412a-ba76-f8d56b767a8d','2025-12-10 15:29:12'),
(181,101688,'60ad6f69-53b7-48f6-a848-488cbb098150','2025-12-10 15:29:13'),
(182,101688,'21750a61-d6b2-4031-a427-78299ddf5eab','2025-12-10 15:29:13'),
(183,101688,'e9d76c22-7535-45ad-ab6d-93fdea16d7ca','2025-12-10 15:29:14'),
(184,101688,'5a9f8d29-b03a-4d05-9245-79df59346d9f','2025-12-10 15:29:14'),
(185,101688,'127668be-9bda-4682-bf0c-e406c7fc6802','2025-12-10 15:29:15'),
(186,102,'772bdd46-5193-4880-aef1-ed3f82bcc034','2025-12-15 09:10:11'),
(187,101696,'f1a21174-dd5f-4d8c-9dd4-b7cf0e0eac02','2025-12-15 09:10:12'),
(188,101696,'b260759f-d13b-49a1-a8cd-f3ec8e0b20ec','2025-12-15 09:10:12'),
(189,101696,'fcdc4c8b-2b50-42e1-8483-644e7847280e','2025-12-15 09:10:13'),
(190,101696,'39c23981-3f3a-4678-900b-97fc0ca1a799','2025-12-15 09:10:13'),
(191,101696,'aeafbc0f-8126-446f-b7a1-034681100c30','2025-12-15 09:10:13'),
(192,103,'772bdd46-5193-4880-aef1-ed3f82bcc034','2025-12-15 09:10:14'),
(193,101697,'f1a21174-dd5f-4d8c-9dd4-b7cf0e0eac02','2025-12-15 09:10:14'),
(194,101697,'b260759f-d13b-49a1-a8cd-f3ec8e0b20ec','2025-12-15 09:10:14'),
(195,101697,'fcdc4c8b-2b50-42e1-8483-644e7847280e','2025-12-15 09:10:14'),
(196,101697,'39c23981-3f3a-4678-900b-97fc0ca1a799','2025-12-15 09:10:15'),
(197,101697,'aeafbc0f-8126-446f-b7a1-034681100c30','2025-12-15 09:10:15'),
(198,104,'aeafbc0f-8126-446f-b7a1-034681100c30','2025-12-15 11:00:00'),
(199,101700,'f1a21174-dd5f-4d8c-9dd4-b7cf0e0eac02','2025-12-15 11:00:00'),
(200,101700,'b260759f-d13b-49a1-a8cd-f3ec8e0b20ec','2025-12-15 11:00:00'),
(201,101700,'fcdc4c8b-2b50-42e1-8483-644e7847280e','2025-12-15 11:00:00'),
(202,101700,'772bdd46-5193-4880-aef1-ed3f82bcc034','2025-12-15 11:00:00'),
(203,101700,'39c23981-3f3a-4678-900b-97fc0ca1a799','2025-12-15 11:00:00'),
(204,200,'9fde6d2d-39c2-4329-b2c2-50045030f009','2025-12-15 21:02:29'),
(205,201,'9fde6d2d-39c2-4329-b2c2-50045030f009','2025-12-15 21:05:02'),
(206,202,'9fde6d2d-39c2-4329-b2c2-50045030f009','2025-12-15 21:27:06'),
(207,209,'9fde6d2d-39c2-4329-b2c2-50045030f009','2025-12-15 22:35:12'),
(208,210,'9fde6d2d-39c2-4329-b2c2-50045030f009','2025-12-15 22:38:16'),
(209,226,'9fde6d2d-39c2-4329-b2c2-50045030f009','2025-12-15 23:47:37'),
(210,228,'9fde6d2d-39c2-4329-b2c2-50045030f009','2025-12-15 23:48:37'),
(211,229,'9fde6d2d-39c2-4329-b2c2-50045030f009','2025-12-15 23:52:39'),
(212,101831,'41219a51-9670-4b8c-9a9e-0dc5119e4f4c','2025-12-15 23:52:39'),
(213,230,'b4677447-bb34-496e-b876-c7924b2fe7b0','2025-12-16 11:11:12'),
(214,101832,'89fbd8cf-99f5-4546-b88b-64341a30da16','2025-12-16 11:11:13'),
(215,101832,'184238b6-771b-4a53-980e-365941c23cc9','2025-12-16 11:11:13'),
(216,101832,'521d5610-6a16-4549-af75-13e27014b10e','2025-12-16 11:11:14'),
(217,101832,'07c01ae0-8903-4e0c-9369-a8f7921f4a47','2025-12-16 11:11:14'),
(218,101832,'4e06d080-d419-4571-9cf7-f88ed7079770','2025-12-16 11:11:15'),
(219,101832,'e628cdec-665e-49ed-b28d-6212f8a2fcaa','2025-12-16 11:11:15'),
(220,231,'169dd025-f7c6-4488-b806-6c7b8f1e2c85','2025-12-16 12:11:44'),
(221,101833,'106fd2f0-edbb-493e-a6e0-e33c1f0911f3','2025-12-16 12:11:44'),
(222,101833,'c0433a8d-ee08-45ff-a294-70b1a7abc5cf','2025-12-16 12:11:45'),
(223,232,'169dd025-f7c6-4488-b806-6c7b8f1e2c85','2025-12-16 13:56:16'),
(224,101838,'106fd2f0-edbb-493e-a6e0-e33c1f0911f3','2025-12-16 13:56:16'),
(225,101838,'c0433a8d-ee08-45ff-a294-70b1a7abc5cf','2025-12-16 13:56:17'),
(226,233,'169dd025-f7c6-4488-b806-6c7b8f1e2c85','2025-12-16 14:07:06'),
(227,101839,'106fd2f0-edbb-493e-a6e0-e33c1f0911f3','2025-12-16 14:07:06'),
(228,101839,'f212e947-7b8c-4085-97d5-71c0ab49d8b2','2025-12-16 14:07:07'),
(229,101839,'c0433a8d-ee08-45ff-a294-70b1a7abc5cf','2025-12-16 14:07:07'),
(230,234,'169dd025-f7c6-4488-b806-6c7b8f1e2c85','2025-12-16 15:34:34'),
(231,101841,'106fd2f0-edbb-493e-a6e0-e33c1f0911f3','2025-12-16 15:34:34'),
(232,101841,'c0433a8d-ee08-45ff-a294-70b1a7abc5cf','2025-12-16 15:34:35'),
(233,101841,'f212e947-7b8c-4085-97d5-71c0ab49d8b2','2025-12-16 15:34:35'),
(234,235,'106fd2f0-edbb-493e-a6e0-e33c1f0911f3','2025-12-16 15:45:21'),
(235,101843,'169dd025-f7c6-4488-b806-6c7b8f1e2c85','2025-12-16 15:45:21'),
(236,101843,'c0433a8d-ee08-45ff-a294-70b1a7abc5cf','2025-12-16 15:45:22'),
(237,101843,'f212e947-7b8c-4085-97d5-71c0ab49d8b2','2025-12-16 15:45:22'),
(238,236,'c0433a8d-ee08-45ff-a294-70b1a7abc5cf','2025-12-16 16:20:20'),
(239,101844,'169dd025-f7c6-4488-b806-6c7b8f1e2c85','2025-12-16 16:20:20'),
(240,237,'169dd025-f7c6-4488-b806-6c7b8f1e2c85','2025-12-17 01:04:16'),
(241,101847,'22d2f060-37e6-4c45-ad0d-6ab8f2c34858','2025-12-17 01:04:17'),
(242,101847,'106fd2f0-edbb-493e-a6e0-e33c1f0911f3','2025-12-17 01:04:17'),
(243,101847,'c0433a8d-ee08-45ff-a294-70b1a7abc5cf','2025-12-17 01:04:17'),
(244,101847,'f212e947-7b8c-4085-97d5-71c0ab49d8b2','2025-12-17 01:04:17'),
(245,238,'5c630052-726d-41db-90d8-9b1868078403','2025-12-17 01:41:48'),
(246,101849,'a18bdd06-9c9f-44e1-b855-ef1d2bb62105','2025-12-17 01:41:49'),
(247,101849,'019dc17a-cf07-4595-bd37-eb4acc74a0be','2025-12-17 01:41:49'),
(248,239,'18c0898f-d5a3-49ec-9c3a-378cad74c6ee','2025-12-17 01:53:00'),
(249,101851,'36f99637-39b7-4c7c-b242-9a85bf328b48','2025-12-17 01:53:00'),
(250,101851,'65555bf4-771d-4ed7-aca1-9c95a31594f9','2025-12-17 01:53:00'),
(251,241,'68b6e099-850f-46a4-ba54-7244d806a0a5','2025-12-17 05:04:49'),
(252,101858,'d5a930db-8375-4e76-a296-2d64801f9e9a','2025-12-17 05:04:50'),
(253,101858,'eb3b7052-94a8-47fa-b68f-1623ba7ee14b','2025-12-17 05:04:50'),
(254,101858,'6b2e3a16-59c0-4fc6-ace4-a3fada8fab8b','2025-12-17 05:04:50');
/*!40000 ALTER TABLE `group_chat_participant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `language` (
  `language_code` varchar(2) NOT NULL,
  `consultant_id` varchar(36) NOT NULL,
  PRIMARY KEY (`consultant_id`,`language_code`),
  CONSTRAINT `language_id_consultant_constraint` FOREIGN KEY (`consultant_id`) REFERENCES `consultant` (`consultant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `session` (
  `id` bigint(21) unsigned NOT NULL,
  `tenant_id` bigint(21) DEFAULT NULL,
  `user_id` varchar(36) NOT NULL,
  `consultant_id` varchar(36) DEFAULT NULL,
  `consulting_type` tinyint(4) NOT NULL,
  `registration_type` varchar(20) NOT NULL DEFAULT 'REGISTERED',
  `message_date` datetime DEFAULT NULL,
  `assign_date` datetime DEFAULT NULL,
  `postcode` varchar(5) NOT NULL,
  `agency_id` bigint(21) unsigned DEFAULT NULL,
  `language_code` varchar(2) NOT NULL DEFAULT 'de',
  `rc_group_id` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `is_team_session` tinyint(4) NOT NULL DEFAULT 0,
  `is_consultant_directly_set` bit(1) NOT NULL DEFAULT b'0',
  `create_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `update_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `main_topic_id` bigint(21) DEFAULT NULL,
  `user_gender` varchar(50) DEFAULT NULL,
  `user_age` int(11) DEFAULT NULL,
  `counselling_relation` varchar(50) DEFAULT NULL,
  `referer` varchar(50) DEFAULT NULL,
  `matrix_room_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_consultant_id_status` (`consultant_id`,`status`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `session_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE,
  CONSTRAINT `session_ibfk_2` FOREIGN KEY (`consultant_id`) REFERENCES `consultant` (`consultant_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES
(101866,NULL,'9045f32f-3566-4ec4-90c5-cc7db730174e',NULL,1,'REGISTERED',NULL,NULL,'12345',179,'de',NULL,1,0,'\0','2025-12-17 07:28:22','2025-12-17 07:28:22',2,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`userservice`@`%`*/ /*!50003 TRIGGER `userservice`.`session_update` BEFORE UPDATE ON `userservice`.`session` FOR EACH ROW BEGIN
set new.update_date=utc_timestamp();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`userservice`@`%`*/ /*!50003 TRIGGER `userservice`.`assign_date_update` BEFORE UPDATE ON `userservice`.`session` FOR EACH ROW BEGIN
    IF OLD.assign_date IS NULL AND OLD.status = 1 AND NEW.status = 2 THEN
        SET NEW.assign_date=utc_timestamp();
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `session_data`
--

DROP TABLE IF EXISTS `session_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `session_data` (
  `id` bigint(21) unsigned NOT NULL,
  `session_id` bigint(21) unsigned NOT NULL,
  `type` tinyint(4) NOT NULL,
  `key_name` varchar(255) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `create_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `update_date` datetime NOT NULL DEFAULT utc_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_type_key_name` (`session_id`,`type`,`key_name`),
  KEY `session_id` (`session_id`),
  CONSTRAINT `session_data_ibfk_2` FOREIGN KEY (`session_id`) REFERENCES `session` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_data`
--

LOCK TABLES `session_data` WRITE;
/*!40000 ALTER TABLE `session_data` DISABLE KEYS */;
INSERT INTO `session_data` VALUES
(0,100103,0,'age','null','2025-09-14 10:48:48','2025-09-14 10:48:48'),
(1,100103,0,'state',NULL,'2025-09-14 10:48:48','2025-09-14 10:48:48'),
(2,100104,0,'age','null','2025-09-14 11:04:24','2025-09-14 11:04:24'),
(3,100104,0,'state',NULL,'2025-09-14 11:04:24','2025-09-14 11:04:24'),
(4,100105,0,'age','null','2025-09-14 11:08:21','2025-09-14 11:08:21'),
(5,100105,0,'state',NULL,'2025-09-14 11:08:21','2025-09-14 11:08:21'),
(6,100106,0,'age','null','2025-09-14 11:09:27','2025-09-14 11:09:27'),
(7,100106,0,'state',NULL,'2025-09-14 11:09:27','2025-09-14 11:09:27'),
(8,100107,0,'age','null','2025-09-14 11:19:15','2025-09-14 11:19:15'),
(9,100107,0,'state',NULL,'2025-09-14 11:19:15','2025-09-14 11:19:15'),
(10,100108,0,'age','null','2025-09-14 11:22:18','2025-09-14 11:22:18'),
(11,100108,0,'state',NULL,'2025-09-14 11:22:18','2025-09-14 11:22:18'),
(12,100109,0,'age','null','2025-09-14 11:26:04','2025-09-14 11:26:04'),
(13,100109,0,'state',NULL,'2025-09-14 11:26:04','2025-09-14 11:26:04'),
(14,100110,0,'age','null','2025-09-14 11:28:29','2025-09-14 11:28:29'),
(15,100110,0,'state',NULL,'2025-09-14 11:28:29','2025-09-14 11:28:29'),
(16,100111,0,'age','null','2025-09-14 11:31:09','2025-09-14 11:31:09'),
(17,100111,0,'state',NULL,'2025-09-14 11:31:09','2025-09-14 11:31:09'),
(18,100112,0,'age','null','2025-09-14 11:32:22','2025-09-14 11:32:22'),
(19,100112,0,'state',NULL,'2025-09-14 11:32:22','2025-09-14 11:32:22'),
(20,100113,0,'age','null','2025-09-14 11:34:37','2025-09-14 11:34:37'),
(21,100113,0,'state',NULL,'2025-09-14 11:34:37','2025-09-14 11:34:37'),
(22,100114,0,'age','null','2025-09-14 11:38:06','2025-09-14 11:38:06'),
(23,100114,0,'state',NULL,'2025-09-14 11:38:06','2025-09-14 11:38:06'),
(24,100115,0,'age','null','2025-09-14 11:39:56','2025-09-14 11:39:56'),
(25,100115,0,'state',NULL,'2025-09-14 11:39:56','2025-09-14 11:39:56'),
(26,100116,0,'age','null','2025-09-14 11:42:53','2025-09-14 11:42:53'),
(27,100116,0,'state',NULL,'2025-09-14 11:42:53','2025-09-14 11:42:53'),
(28,100117,0,'age','null','2025-09-14 11:52:17','2025-09-14 11:52:17'),
(29,100117,0,'state',NULL,'2025-09-14 11:52:17','2025-09-14 11:52:17'),
(30,100118,0,'age','null','2025-09-14 11:54:17','2025-09-14 11:54:17'),
(31,100118,0,'state',NULL,'2025-09-14 11:54:17','2025-09-14 11:54:17'),
(32,100119,0,'age','null','2025-09-14 12:02:24','2025-09-14 12:02:24'),
(33,100119,0,'state',NULL,'2025-09-14 12:02:24','2025-09-14 12:02:24'),
(34,100120,0,'age','null','2025-09-14 12:04:21','2025-09-14 12:04:21'),
(35,100120,0,'state',NULL,'2025-09-14 12:04:21','2025-09-14 12:04:21'),
(36,100121,0,'age','null','2025-09-14 12:11:02','2025-09-14 12:11:02'),
(37,100121,0,'state',NULL,'2025-09-14 12:11:02','2025-09-14 12:11:02'),
(38,100122,0,'age','null','2025-09-14 12:27:06','2025-09-14 12:27:06'),
(39,100122,0,'state',NULL,'2025-09-14 12:27:06','2025-09-14 12:27:06'),
(40,100123,0,'age','null','2025-09-14 12:31:17','2025-09-14 12:31:17'),
(41,100123,0,'state',NULL,'2025-09-14 12:31:17','2025-09-14 12:31:17'),
(42,100124,0,'age','null','2025-09-14 12:33:51','2025-09-14 12:33:51'),
(43,100124,0,'state',NULL,'2025-09-14 12:33:51','2025-09-14 12:33:51'),
(44,100125,0,'age','null','2025-09-14 12:41:40','2025-09-14 12:41:40'),
(45,100125,0,'state',NULL,'2025-09-14 12:41:40','2025-09-14 12:41:40'),
(46,100126,0,'age','null','2025-09-14 12:59:03','2025-09-14 12:59:03'),
(47,100126,0,'state',NULL,'2025-09-14 12:59:03','2025-09-14 12:59:03');
/*!40000 ALTER TABLE `session_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`userservice`@`%`*/ /*!50003 TRIGGER `userservice`.`session_data_update` BEFORE UPDATE ON `userservice`.`session_data` FOR EACH ROW BEGIN
set new.update_date=utc_timestamp();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `session_topic`
--

DROP TABLE IF EXISTS `session_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `session_topic` (
  `id` bigint(21) NOT NULL,
  `session_id` bigint(21) unsigned NOT NULL,
  `topic_id` bigint(21) unsigned NOT NULL,
  `create_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `update_date` datetime NOT NULL DEFAULT utc_timestamp(),
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`),
  CONSTRAINT `session_topic_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `session` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_topic`
--

LOCK TABLES `session_topic` WRITE;
/*!40000 ALTER TABLE `session_topic` DISABLE KEYS */;
/*!40000 ALTER TABLE `session_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` varchar(36) NOT NULL,
  `tenant_id` bigint(21) DEFAULT NULL,
  `id_old` bigint(21) unsigned DEFAULT NULL,
  `delete_date` datetime DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `rc_user_id` varchar(255) DEFAULT NULL,
  `matrix_user_id` varchar(255) DEFAULT NULL,
  `language_formal` tinyint(4) NOT NULL DEFAULT 0,
  `data_privacy_confirmation` datetime DEFAULT NULL,
  `terms_and_conditions_confirmation` datetime DEFAULT NULL,
  `language_code` varchar(2) NOT NULL DEFAULT 'de',
  `encourage_2fa` bit(1) NOT NULL DEFAULT b'1',
  `create_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `update_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `mobile_token` longtext DEFAULT NULL,
  `notifications_enabled` tinyint(4) unsigned NOT NULL DEFAULT 0,
  `notifications_settings` varchar(4000) DEFAULT '',
  `matrix_password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES
('9045f32f-3566-4ec4-90c5-cc7db730174e',NULL,NULL,NULL,'enc.MRUXE23NL5ZGC5DMN5ZQ....','9045f32f-3566-4ec4-90c5-cc7db730174e@beratungcaritas.de',NULL,NULL,1,'2025-12-17 07:28:22','2025-12-17 07:28:22','de','','2025-12-17 07:28:22','2025-12-17 07:28:22',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`userservice`@`%`*/ /*!50003 TRIGGER `userservice`.`user_update` BEFORE UPDATE ON `userservice`.`user` FOR EACH ROW BEGIN
set new.update_date=utc_timestamp();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `user_agency`
--

DROP TABLE IF EXISTS `user_agency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_agency` (
  `id` bigint(21) unsigned NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `agency_id` bigint(21) unsigned NOT NULL,
  `create_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `update_date` datetime NOT NULL DEFAULT utc_timestamp(),
  PRIMARY KEY (`id`),
  KEY `chat_id` (`user_id`),
  CONSTRAINT `user_agency_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_agency`
--

LOCK TABLES `user_agency` WRITE;
/*!40000 ALTER TABLE `user_agency` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_agency` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`userservice`@`%`*/ /*!50003 TRIGGER `userservice`.`user_agency_update` BEFORE UPDATE ON `userservice`.`user_agency` FOR EACH ROW BEGIN
set new.update_date=utc_timestamp();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `user_chat`
--

DROP TABLE IF EXISTS `user_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_chat` (
  `id` bigint(21) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `chat_id` bigint(21) unsigned NOT NULL,
  `create_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `update_date` datetime NOT NULL DEFAULT utc_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `UniqueUserAndChat` (`user_id`,`chat_id`),
  KEY `chat_id` (`chat_id`),
  CONSTRAINT `chat_user_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE,
  CONSTRAINT `chat_user_ibfk_2` FOREIGN KEY (`chat_id`) REFERENCES `chat` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_chat`
--

LOCK TABLES `user_chat` WRITE;
/*!40000 ALTER TABLE `user_chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_mobile_token`
--

DROP TABLE IF EXISTS `user_mobile_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_mobile_token` (
  `id` bigint(21) unsigned NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `mobile_app_token` longtext NOT NULL,
  `create_date` datetime NOT NULL DEFAULT utc_timestamp(),
  `update_date` datetime NOT NULL DEFAULT utc_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobile_app_token` (`mobile_app_token`) USING HASH,
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_mobile_token_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_mobile_token`
--

LOCK TABLES `user_mobile_token` WRITE;
/*!40000 ALTER TABLE `user_mobile_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_mobile_token` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`userservice`@`%`*/ /*!50003 TRIGGER `userservice`.`user_mobile_token_update`
    BEFORE UPDATE ON `userservice`.`user_mobile_token`
    FOR EACH ROW BEGIN set new.update_date=utc_timestamp();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Dumping events for database 'userservice'
--

--
-- Dumping routines for database 'userservice'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-17  7:44:54
